# fdth news

## 1.3-4 (2026-05-11) - Faria, J. C.

- Added **testthat**-based tests under `tests/testthat/` (including checks for `summary(..., format.classes = TRUE, pattern = "%.2f")` using normal R strings, avoiding `\%` quoting issues from `.Rd` examples).
- `quantile.fdt` now returns a named numeric vector (for example, `25%`, `50%`, `75%`), with tests and documentation updates for this behavior.
- Improved vignette didactics in `vignettes/latex_fdt.Rnw` with a quick-start section, a compact `xtable::print` arguments guide, reproducible categorical examples, and closing takeaways.
- Refactored `mfv.default` to return all modal values in multimodal cases.
- Refactored `mfv.fdt` to detect modal classes robustly and return multimodal results.
- Updated `mfv.Rd` with multimodal examples, including a deterministic non-adjacent modal-class case.
- Revised package documentation English in `.Rd` files for clarity and consistency.
- Refactored `README.md` to a modern style, added CRAN badges, and set lifecycle badge to stable.
- Added `NEWS.md` in Markdown format.
- Improvements were made to the documentation of the package and functions.

## 1.3-0 (2023-11-17) - Faria, J. C.

- Adjustment of files encoding as required by the CRAN.
- Adjustments and improvements were made to the documentation
  of the package and functions.

## 1.2-6 (2021-10-11) - Faria, J. C.

- The "na.omit" function, previously used in several methods of the package,
  has been removed. The main use was in the functions: "fdt.default",
  "make.ft.multiple", "fdt_cat.default", "fdt_cat.matrix" and "fdt_cat.data.frame".
- Added "na.rm" argument to methods associated with default FALSE.
  If you have NA values that can influence the structure of the table,
  the user will receive a error message.

## 1.2-5 (2020-04-17) - Allaman, I. B.

- Correction of wording of argument x in file fdt.Rd. Removed the snippet
  "or character/factor ('fdt_cat')".
- The functions latex.fdt, latex.fdt_cat, latex.fdt_cat.multiple,
  print.latex.fdt and summary.latex.fdt was deprecated. Add the new class to
  the xtable function: xtable.fdt and xtable.fdt.multiple.
- Corrected bug in plot.fdt.default function, types "cdh" and "cdp".
  The relative frequencies not was divide by h (amplitude of the class).
- Add news arguments in the plot.fdt.multiple: grouped - if the "by"
  argument is different from NULL, then the users have the option the to plot
  factors in a the same graphics; args.legend - a list with the same arguments
  of the legend function of the graphics package.

## 1.2-4 (2018-02-17) - Allaman, I. B.

- Only available on GitHub (under test)
- Remove "tmp" object of the fdt.default.R function in the 51 line. That
  object was desnecessary.

## 1.2-3 (2015-12-28) - Allaman, I. B.

- Only available on GitHub (under test)
- Added the "round" argument in the functions latex.fdt_cat and
  latex.fdt_cat.multiple.

## 1.2-2 (2015-04-13) - Faria, J. C.

- Only available on GitHub (under test)
- The documentation has been improved.

## 1.2-1 (2015-04-09) - Allaman, I. B.

- Ivan Bezerra Allaman has began to work in the project as co-author.
- Added the "by" argument to fdt_cat.data.frame function. As consequence,
  the print.fdt_cat.multiple, plot.fdt_cat.multiple, make.fdt_cat.multiple,
  fdt_cat.matrix functions were changed.
- Was added the latex.fdt_cat.multiple function to give suport the objects
  of the fdt_cat.multiple class.
- The Rd files make.fdt_cat.simple, make.fdt_cat.multiple,
  make.fdt.format.classes, make.fdt.multiple and make.fdt.simple were moved
  from the documentation.

## 1.2-0 (2014-10-13) - Faria, J. C.

- Thanks to Ivan B. Allaman to the bug fix of the function make.fdt.simple.R.
- It was added basic suport to categorical variables.
- Some bugs were corrected.

## 1.1-8 (2013-11-22) - Faria, J. C.

- plot.fdth.multiple: x11() was replaced by the portable way dev.new().
- The documentation has been deeply improved.
- Export LaTeX table of the frequency distribution table (latex.fdt).

## 1.1-7 (2012-04-02) - Faria, J. C.

- Cosmetic changes to meet the requirements of CRAN.

## 1.1-6 (2011-08-21) - Faria, J. C.

- The S3 methods print.fdt.default and print.fdt.multiple were improved.
- The S3 methods summary.fdt.default and summary.fdt.multiple were improved.

## 1.1-5 (2011-05-07) - Faria, J. C.

- The S3 methods plot.default and plot.multiple were improved.
  Both enable adding the count values to all types of plot.

## 1.1-3 (2011-04-12) - Faria, J. C.

- The MASS package is not essential and was removed from some examples
  to avoid NOTES in compilation.

## 1.1-2 (2010-05-27) - Faria, J. C.

- The S3 methods plot.default and plot.multiple were improved.

## 1.1-1 (2010-05-22) - Faria, J. C.

- The slot data was removed from the fdt object.
- The S3 methods plot.default and plot.multiple were improved.

## 1.1-0 (2010-05-20) - Faria, J. C.

- Released to CRAN.

## 1.0-0 (2010-05-16) - Faria, J. C.

- Restrict to testers.
